#![allow(dead_code)]
extern crate self as reliquary_memory;
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct MemoryId(pub [u8; 32]);
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct CommunityId(pub [u8; 32]);
pub mod freshness {
    #[path = "C:/!bin/workspace/Reliquary-freshness-performance/src/freshness/policy.rs"]
    pub mod policy;
    #[path = "C:/!bin/workspace/Reliquary-freshness-performance/src/freshness/propagation.rs"]
    pub mod propagation;
    pub use policy::FreshnessPolicy;
    pub use propagation::{
        CommunityMembership, MemoryAdjacency, PropagationEvent, propagate_events_with_policy,
        propagate_with_policy,
    };
}
pub use freshness::propagation::{CommunityMembership, MemoryAdjacency, PropagationEvent};
#[cfg(test)]
#[path = "C:/!bin/workspace/Reliquary-freshness-performance/tests/freshness_propagation_oracle.rs"]
mod independent_oracle;
