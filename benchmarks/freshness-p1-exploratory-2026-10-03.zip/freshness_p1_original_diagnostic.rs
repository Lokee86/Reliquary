#![allow(dead_code)]
use std::collections::{BTreeMap, BTreeSet};
use std::time::Instant;
#[derive(Clone,Copy,Debug,Eq,PartialEq,Ord,PartialOrd,Hash)]
pub struct MemoryId(pub [u8;32]);
#[derive(Clone,Copy,Debug,Eq,PartialEq,Ord,PartialOrd,Hash)]
pub struct CommunityId(pub [u8;32]);
mod freshness {
    #[path = "C:/!bin/workspace/Reliquary-freshness-baseline/src/freshness/policy.rs"]
    pub mod policy;
    #[path = "C:/!bin/workspace/Reliquary-freshness-baseline/src/freshness/propagation.rs"]
    pub mod propagation;
}
use freshness::propagation::*;
fn mem(c:u8,n:u8)->MemoryId{let mut a=[0u8;32];a[0]=c;a[1]=n;MemoryId(a)}
fn community(c:u8)->CommunityId{let mut a=[0u8;32];a[0]=c;CommunityId(a)}
fn add(g:&mut MemoryAdjacency,a:MemoryId,b:MemoryId){
    g.entry(a).or_default().insert(b);
    g.entry(b).or_default().insert(a);
}
fn graph()->(MemoryAdjacency,CommunityMembership){
    let(mut g,mut m)=(MemoryAdjacency::new(),CommunityMembership::new());
    for c in 0..32u8{
        for n in 0..64u8{
            m.insert(mem(c,n),community(c));
            for d in [1u8,2,5,11]{add(&mut g,mem(c,n),mem(c,(n+d)%64));}
        }
    }
    for c in 0..32u8{add(&mut g,mem(c,63),mem((c+1)%32,0));}
    (g,m)
}
fn median(a:&mut[u128])->u128{a.sort_unstable();a[a.len()/2]}
fn probe(label:&str,event:&PropagationEvent,g:&MemoryAdjacency,m:&CommunityMembership){
    let mut sample=Vec::new();
    for _ in 0..25{
        let start=Instant::now();
        let result=propagate_with_stats(event,g,m,1).unwrap();
        let micros=start.elapsed().as_micros();
        sample.push(micros);
        if sample.len()==1{
            println!("{} recipients={} edges={} expansions={} effective_workers={}",label,
            result.candidates.len(),result.stats.examined_edges,result.stats.candidate_expansions,result.stats.worker_count);
        }
    }
    println!("{} median_us={}",label,median(&mut sample));
}
fn main(){
    let(g,m)=graph();
    let same=PropagationEvent{roots:(0..8).map(|n|mem(0,n)).collect(),principal:50,excluded:BTreeSet::new()};
    let across=PropagationEvent{roots:(0..8).map(|c|mem(c,0)).collect(),principal:50,excluded:BTreeSet::new()};
    probe("dream_8_same",&same,&g,&m);
    probe("dream_8_across",&across,&g,&m);
    let one=PropagationEvent{roots:vec![mem(0,0)],principal:25,excluded:BTreeSet::new()};
    probe("access_1",&one,&g,&m);
    let events=(0..64).map(|n|PropagationEvent{roots:vec![mem(0,n)],principal:25,excluded:BTreeSet::new()}).collect::<Vec<_>>();
    for w in [1,4,8]{
        let mut samples=Vec::new();
        for _ in 0..15{
            let start=Instant::now();
            let outcomes=propagate_events_with_policy(&events,&g,&m,w,&freshness::policy::FreshnessPolicy::default()).unwrap();
            samples.push(start.elapsed().as_micros());
            assert_eq!(outcomes.len(),64);
        }
        println!("access_batch_64 workers={} median_us={}",w,median(&mut samples));
    }
}