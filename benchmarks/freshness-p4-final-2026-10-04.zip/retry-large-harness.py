"""Fresh-history retry follow-up: Large-history four-memory retry follow-up: nine matched pairs."""
import sys,pathlib,os,json,statistics
sys.path.insert(0,'scripts')
import freshness_p2_acceptance as guard
p=pathlib.Path(os.environ['TEMP'])/'reliquary-freshness-p4';out=p/'final';data=[]
assert len(json.loads((out/'raw.json').read_text()))==72
guard.QUIET_REQUIRED=True
for mode,rounds,variants in [('matched',9,{'baseline':p/'baseline.exe','candidate':p/'candidate.exe'})]:
 for iteration in range(rounds):
  for batch in [4]:
   order=list(variants) if iteration%2==0 else list(reversed(variants));identities=[]
   for label in order:
    name=f'retry-large-{mode}-{label}-batch{batch}-round{iteration}';print(name,flush=True)
    so=out/(name+'.stdout.jsonl');se=out/(name+'.stderr.jsonl')
    env={**os.environ,'RELIQUARY_FRESHNESS_TRACE':'1','RELIQUARY_FRESHNESS_HISTORY_DEPTH':'1024','RELIQUARY_FRESHNESS_HISTORY_BATCH':str(batch)}
    guard.run([str(variants[label])],so,se,env=env)
    rows=[json.loads(l) for l in so.read_text(encoding='utf-8').splitlines() if l.startswith('{')]
    identities.append(next(r for r in rows if r['kind']=='freshness_history_identity'))
    samples={r['stage']:r['elapsed_ns'] for r in rows if r['kind']=='freshness_operation_sample'}
    data.append({'mode':mode,'round':iteration,'batch':batch,'variant':label,'use_ns':samples['history_accepted_use'],'retry_ns':samples['history_exact_retry']})
   assert identities[0]==identities[1]
   (out/'retry-large-raw.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
summary=[]
for mode in ['matched']:
 for batch in [4]:
  labels=['baseline','candidate'] if mode=='matched' else ['candidate_a','candidate_b']
  groups={v:[r for r in data if (r['mode'],r['batch'],r['variant'])==(mode,batch,v)] for v in labels}
  metrics={v:{'retry_p50_ns':statistics.median(r['retry_ns'] for r in group),'retry_samples_ns':[r['retry_ns'] for r in group],'use_p50_ns':statistics.median(r['use_ns'] for r in group)} for v,group in groups.items()}
  ratio=metrics[labels[1]]['retry_p50_ns']/metrics[labels[0]]['retry_p50_ns']
  summary.append({'mode':mode,'depth':1024,'batch':batch,'metrics':metrics,'second_over_first_retry_p50':ratio})
(out/'retry-large-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
(out/'retry-large-load.json').write_text(json.dumps(guard.LOAD_OBSERVATIONS,indent=2),encoding='utf-8')
print(json.dumps(summary),flush=True)
