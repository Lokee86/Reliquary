from pathlib import Path
import json,statistics
p=Path.home()/'AppData/Local/Temp/reliquary-freshness-p6/measurement'
def read(name):return json.loads((p/name).read_text(encoding='utf-8'))
def quant(values):
 s=sorted(values);return {'raw_ns':values,'p50_ns':statistics.median(s),'p95_ns':s[(len(s)*95+99)//100-1],'p99_ns':s[(len(s)*99+99)//100-1]}
summary=read('summary.json')
print('comparisons',len(summary['comparisons']),'graph_flags',len(summary['propagation_regressions_over_10_percent_p95']))
for r in summary['propagation_regressions_over_10_percent_p95']:print('GRAPH_FLAG',r)
for name in ['operation-summary.json','history-summary.json']:
 print(name)
 for r in read(name):
  print(r.get('depth',''),r.get('batch',''),r['stage'],'p50-ms',round(r['baseline']['p50_ns']/1e6,6),round(r['candidate']['p50_ns']/1e6,6),'p95-ms',round(r['baseline']['p95_ns']/1e6,6),round(r['candidate']['p95_ns']/1e6,6),'ratio',round(r['candidate_over_baseline_p95'],4))
# Indexed trace scopes preserve fixture ordering; do not combine different receipts/root counts.
scopes={}
for variant in ['baseline','candidate']:
 for file in sorted(p.glob(f'operation-{variant}-round*.stderr.jsonl')):
  rows=[json.loads(line) for line in file.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
  for index,row in enumerate(rows):
   totals={}
   for sample in row['samples']:
    totals[sample['stage']]=totals.get(sample['stage'],0)+sample['elapsed_ns']
   for stage,total in totals.items():
    key=(variant,index,row['operation'],stage)
    scopes.setdefault(key,[]).append(total)
traces=[{'variant':key[0],'scope_index':key[1],'operation':key[2],'stage':key[3],**quant(values)} for key,values in sorted(scopes.items())]
(p/'trace-stage-summary.json').write_text(json.dumps(traces,indent=2),encoding='utf-8')
hist=[]
for variant in ['baseline','candidate']:
 for file in sorted(p.glob(f'history-{variant}-*.stderr.jsonl')):
  rows=[json.loads(line) for line in file.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
  hist.append({'file':file.name,'use_scope':rows[-2],'retry_scope':rows[-1]})
(p/'history-stage-raw.json').write_text(json.dumps(hist,indent=2),encoding='utf-8')
print('trace-scope counts', {v:len({r['scope_index'] for r in traces if r['variant']==v}) for v in ['baseline','candidate']})
rss=read('peak-working-set.json')
for family in ['propagation','operation','history']:
 for variant in ['baseline','candidate']:
  values=[r['peak_process_working_set_bytes'] for r in rss if r['sample'].startswith(family+'-') and variant in r['sample'] and r['peak_process_working_set_bytes'] is not None]
  print('PEAK',family,variant,'min/max-MiB', [round(min(values)/1048576,3),round(max(values)/1048576,3)] if values else 'unavailable')
