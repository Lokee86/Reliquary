from pathlib import Path
import json,os,sys,statistics
root=Path(r'C:\!bin\workspace\Reliquary-freshness-performance')
sys.path.insert(0,str(root/'scripts'))
import freshness_release_verification as collector
base=Path.home()/'AppData/Local/Temp/reliquary-freshness-p6'
out=base/'history-followup';out.mkdir(exist_ok=True);data=[]
def collect(label,variant,iteration,depth,batch,family,trace=True):
 name=f'{family}-{label}-depth{depth}-batch{batch}-round{iteration}';print(name,flush=True)
 env={**os.environ,'RELIQUARY_FRESHNESS_HISTORY_DEPTH':str(depth),'RELIQUARY_FRESHNESS_HISTORY_BATCH':str(batch)}
 if trace:env['RELIQUARY_FRESHNESS_TRACE']='1'
 else:env.pop('RELIQUARY_FRESHNESS_TRACE',None)
 stdout=out/(name+'.stdout.jsonl');stderr=out/(name+'.stderr.jsonl')
 peak=collector.run([str(base/(variant+'-operation.exe'))],stdout,stderr,env)
 rows=[json.loads(line) for line in stdout.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
 identity=next(r for r in rows if r['kind']=='freshness_history_identity')
 data.append({'label':label,'variant':variant,'round':iteration,'family':family,'depth':depth,'batch':batch,'trace':trace,'samples':[r for r in rows if r['kind']=='freshness_operation_sample'],'identity':identity,'peak_process_working_set_bytes':peak})
 collector.save(out/'raw.json',data);return identity
for iteration in range(9):
 for depth,batch in [(160,1),(1024,1),(1024,64)]:
  identities=[collect(v,v,iteration,depth,batch,'matched') for v in (['baseline','candidate'] if iteration%2==0 else ['candidate','baseline'])]
  assert identities[0]==identities[1]
# Trace-disabled control distinguishes optional instrumentation from ordinary operation.
for iteration in range(9):
 identities=[collect(v,v,iteration,160,1,'trace-off',False) for v in (['baseline','candidate'] if iteration%2==0 else ['candidate','baseline'])]
 assert identities[0]==identities[1]
for iteration in range(6):
 identities=[collect(label,'candidate',iteration,160,1,'aa') for label in (['A','B'] if iteration%2==0 else ['B','A'])]
 assert identities[0]==identities[1]
summary=[]
for family,labels,shapes in [('matched',['baseline','candidate'],[(160,1),(1024,1),(1024,64)]),('trace-off',['baseline','candidate'],[(160,1)]),('aa',['A','B'],[(160,1)])]:
 for depth,batch in shapes:
  for stage in ['history_exact_retry','history_accepted_use']:
   row={'family':family,'depth':depth,'batch':batch,'stage':stage}
   for label in labels:
    chosen=[item for item in data if (item['family'],item['label'],item['depth'],item['batch'])==(family,label,depth,batch)]
    values=[next(r['elapsed_ns'] for r in item['samples'] if r['stage']==stage) for item in chosen]
    row[label]={'raw_ns':values,'p50_ns':statistics.median(values),'p95_ns':collector.percentile(values,95),'p99_ns':collector.percentile(values,99)}
   row['p95_ratio']=row[labels[1]]['p95_ns']/row[labels[0]]['p95_ns'];summary.append(row)
collector.save(out/'summary.json',summary)
collector.save(out/'MANIFEST.json',{'binary_sha256':{v:collector.digest(base/(v+'-operation.exe')) for v in ['baseline','candidate']},'load_observations':collector.guard.LOAD_OBSERVATIONS,'scope':'Prespecified flagged shapes; nine alternating matched pairs per shape, nine trace-disabled pairs at depth160 batch1, six candidate A/A pairs at the same shape. All samples retained.'})
print(json.dumps(summary),flush=True)
