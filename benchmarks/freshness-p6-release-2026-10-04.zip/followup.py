from pathlib import Path
import json,os,sys,statistics,time,hashlib
root=Path(r'C:\!bin\workspace\Reliquary-freshness-performance')
sys.path.insert(0,str(root/'scripts'))
import freshness_release_verification as collector
base=Path.home()/'AppData/Local/Temp/reliquary-freshness-p6'
out=base/'followup';out.mkdir(exist_ok=True)
initial=json.loads((base/'measurement/summary.json').read_text(encoding='utf-8'))
stages=[r['stage'] for r in initial['operation_regressions_over_10_percent_p95']]
data=[]
env={**os.environ,'RELIQUARY_FRESHNESS_TRACE':'1'}
env.pop('RELIQUARY_FRESHNESS_HISTORY_DEPTH',None);env.pop('RELIQUARY_FRESHNESS_HISTORY_BATCH',None)
def collect(label,variant,round,family):
 name=f'{family}-{label}-round{round}';print(name,flush=True)
 stdout=out/(name+'.stdout.jsonl');stderr=out/(name+'.stderr.jsonl')
 peak=collector.run([str(base/(variant+'-operation.exe'))],stdout,stderr,env)
 rows=[json.loads(line) for line in stdout.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
 identity=next(r for r in rows if r['kind']=='freshness_release_identity')
 data.append({'label':label,'variant':variant,'round':round,'family':family,'samples':[r for r in rows if r['kind']=='freshness_operation_sample'],'identity':identity,'peak_process_working_set_bytes':peak})
 collector.save(out/'raw.json',data)
 return identity
for n in range(9):
 identities=[collect(v,v,n,'matched') for v in (['baseline','candidate'] if n%2==0 else ['candidate','baseline'])]
 assert identities[0]==identities[1]
for n in range(6):
 identities=[collect(label,'candidate',n,'aa') for label in (['A','B'] if n%2==0 else ['B','A'])]
 assert identities[0]==identities[1]
summary=[]
for family,labels in [('matched',['baseline','candidate']),('aa',['A','B'])]:
 for stage in stages:
  row={'family':family,'stage':stage}
  for label in labels:
   values=[next(r['elapsed_ns'] for r in item['samples'] if r['stage']==stage) for item in data if (item['family'],item['label'])==(family,label)]
   row[label]={'raw_ns':values,'p50_ns':statistics.median(values),'p95_ns':collector.percentile(values,95),'p99_ns':collector.percentile(values,99)}
  row['p95_ratio']=row[labels[1]]['p95_ns']/row[labels[0]]['p95_ns']
  summary.append(row)
collector.save(out/'summary.json',summary)
collector.save(out/'MANIFEST.json',{'operation_binary_sha256':{v:collector.digest(base/(v+'-operation.exe')) for v in ['baseline','candidate']},'flagged_stages':stages,'load_observations':collector.guard.LOAD_OBSERVATIONS,'scope':'Nine additional alternating P0/final pairs and six identical-candidate A/A pairs; all data retained; p95/p99 are sample maxima at these sample sizes.'})
print(json.dumps(summary),flush=True)
