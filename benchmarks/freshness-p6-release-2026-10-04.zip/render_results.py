from pathlib import Path
import json
p=Path.home()/'AppData/Local/Temp/reliquary-freshness-p6/measurement'
def read(n):return json.loads((p/n).read_text(encoding='utf-8'))
parts=[]
summary=read('summary.json')
parts += [f"Matched topology matrix: {len(summary['comparisons'])} rows, 33 samples per scenario/requested cap. All exact reference effects matched. Two batch-4/current-14-day rows lose propagation time under the deliberately serial P2 threshold; complete receipts are evaluated separately."]
parts += ["| Fixture / scenario / cap | P0 p50 / p95 / p99 ms | Final p50 / p95 / p99 ms | Median speedup | Edges per unique recipient P0 / final | Origin groups |","| --- | ---: | ---: | ---: | ---: | ---: |"]
for fixture in ['synthetic','first14d','first28d','ellis']:
 b=read(f'aggregate-{fixture}-baseline.json');c=read(f'aggregate-{fixture}-candidate.json')
 for scenario,cap in [('dream_roots_8_same',1),('dream_roots_8_unknown',1),('accepted_batch_64',4),('accepted_batch_4',4)]:
  before=next((r for r in b['results'] if (r['scenario_id'],r['requested_workers'])==(scenario,cap)),None)
  if before is None:continue
  after=next(r for r in c['results'] if (r['scenario_id'],r['requested_workers'])==(scenario,cap))
  def latency(row):return ' / '.join(f"{row['operation_latency_ns'][k]/1e6:.3f}" for k in ['p50','p95','p99'])
  def edges(row):
   ev=row['samples'][0]['events'];return sum(e['stats']['examined_edges'] for e in ev)/sum(e['candidate_count'] for e in ev)
  parts.append(f"| {fixture} / {scenario} / {cap} | {latency(before)} | {latency(after)} | {before['operation_latency_ns']['p50']/after['operation_latency_ns']['p50']:.2f}x | {edges(before):.2f} / {edges(after):.2f} | {before['correctness_reference_events'][0]['unique_origin_groups']} |")
parts += ["","Complete operation stages below are milliseconds. Receipt rows time three distinct receipts, with one +25 event per listed Memory in each receipt; they are not one event or per-receipt latency. All worker caps and individual raw values remain archived.","| Stage | P0 p50 / p95 / p99 ms | Final p50 / p95 / p99 ms | Median speedup |","| --- | ---: | ---: | ---: |"]
for r in read('operation-summary.json'):
 def lat(v):return ' / '.join(f"{r[v][k]/1e6:.6f}" for k in ['p50_ns','p95_ns','p99_ns'])
 parts.append(f"| {r['stage']} | {lat('baseline')} | {lat('candidate')} | {r['baseline']['p50_ns']/r['candidate']['p50_ns']:.2f}x |")
parts += ["","Stationary history shapes use 64 published Memories, no active Memory graph, same-turn source-only effects, saturation at 100, and seed construction outside timed samples. Every pair matches payload bytes, accepted event count, current/historical records; each executable verifies current records after reopen.","| Depth / batch / stage | P0 p50 / p95 / p99 ms | Final p50 / p95 / p99 ms | Median speedup |","| --- | ---: | ---: | ---: |"]
for r in read('history-summary.json'):
 def lat(v):return ' / '.join(f"{r[v][k]/1e6:.6f}" for k in ['p50_ns','p95_ns','p99_ns'])
 parts.append(f"| {r['depth']} / {r['batch']} / {r['stage']} | {lat('baseline')} | {lat('candidate')} | {r['baseline']['p50_ns']/r['candidate']['p50_ns']:.2f}x |")
(p/'RESULTS.md').write_text('\n'.join(parts)+'\n',encoding='utf-8')
print('RESULTS.md generated')
