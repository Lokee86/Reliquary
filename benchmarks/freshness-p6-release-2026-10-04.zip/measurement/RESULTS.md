Matched topology matrix: 208 rows, 33 samples per scenario/requested cap. All exact reference effects matched. Two batch-4/current-14-day rows lose propagation time under the deliberately serial P2 threshold; complete receipts are evaluated separately.
| Fixture / scenario / cap | P0 p50 / p95 / p99 ms | Final p50 / p95 / p99 ms | Median speedup | Edges per unique recipient P0 / final | Origin groups |
| --- | ---: | ---: | ---: | ---: | ---: |
| synthetic / dream_roots_8_same / 1 | 2.419 / 2.702 / 3.679 | 0.183 / 0.226 / 0.290 | 13.22x | 52.65 / 8.05 | 1 |
| synthetic / dream_roots_8_unknown / 1 | 1.231 / 1.380 / 1.696 | 0.083 / 0.100 / 0.101 | 14.76x | 43.21 / 8.06 | 1 |
| synthetic / accepted_batch_64 / 4 | 2.290 / 2.869 / 2.946 | 1.173 / 1.502 / 1.628 | 1.95x | 8.05 / 8.05 | 1 |
| synthetic / accepted_batch_4 / 4 | 0.352 / 0.468 / 0.555 | 0.203 / 0.244 / 0.249 | 1.73x | 8.06 / 8.06 | 1 |
| first14d / dream_roots_8_same / 1 | 43.868 / 54.240 / 57.573 | 2.334 / 2.553 / 2.691 | 18.80x | 103.92 / 13.02 | 1 |
| first14d / dream_roots_8_unknown / 1 | 22.844 / 25.579 / 25.898 | 1.297 / 1.756 / 1.872 | 17.62x | 93.96 / 13.03 | 1 |
| first14d / accepted_batch_64 / 4 | 9.038 / 12.499 / 12.621 | 5.412 / 6.431 / 6.478 | 1.67x | 14.32 / 14.32 | 1 |
| first14d / accepted_batch_4 / 4 | 1.014 / 1.198 / 1.624 | 1.404 / 1.549 / 1.927 | 0.72x | 14.58 / 14.58 | 1 |
| first28d / dream_roots_8_unknown / 1 | 47.471 / 53.156 / 65.074 | 4.550 / 4.958 / 4.977 | 10.43x | 89.06 / 16.00 | 1 |
| first28d / accepted_batch_64 / 4 | 3.365 / 4.112 / 4.606 | 1.726 / 2.308 / 2.510 | 1.95x | 18.71 / 18.71 | 1 |
| first28d / accepted_batch_4 / 4 | 0.419 / 0.528 / 0.538 | 0.251 / 0.280 / 0.295 | 1.67x | 19.34 / 19.34 | 1 |
| ellis / dream_roots_8_unknown / 1 | 19.549 / 20.935 / 22.912 | 0.855 / 0.900 / 1.013 | 22.87x | 113.59 / 14.58 | 1 |
| ellis / accepted_batch_64 / 4 | 2.845 / 3.876 / 4.464 | 1.367 / 1.588 / 1.792 | 2.08x | 18.11 / 18.11 | 1 |
| ellis / accepted_batch_4 / 4 | 0.488 / 0.647 / 0.967 | 0.250 / 0.280 / 0.434 | 1.95x | 17.47 / 17.47 | 1 |

Complete operation stages below are milliseconds. Receipt rows time three distinct receipts, with one +25 event per listed Memory in each receipt; they are not one event or per-receipt latency. All worker caps and individual raw values remain archived.
| Stage | P0 p50 / p95 / p99 ms | Final p50 / p95 / p99 ms | Median speedup |
| --- | ---: | ---: | ---: |
| cold_rel_create | 2.581900 / 8.960400 / 8.960400 | 2.681300 / 16.873500 / 16.873500 | 0.96x |
| initial_dream_1_root_prepare_evaluate_commit | 134.748200 / 139.017500 / 139.017500 | 119.481800 / 124.034600 / 124.034600 | 1.13x |
| initial_dream_2_root_prepare_evaluate_commit | 135.535700 / 140.449100 / 140.449100 | 122.815900 / 126.176800 / 126.176800 | 1.10x |
| initial_dream_4_root_prepare_evaluate_commit | 153.383800 / 159.809800 / 159.809800 | 136.380900 / 143.571800 / 143.571800 | 1.12x |
| initial_dream_8_root_prepare_evaluate_commit | 156.016400 / 163.913000 / 163.913000 | 143.561000 / 145.838700 / 145.838700 | 1.09x |
| accepted_use_cold_single_memory_receipt | 21.028400 / 23.139900 / 23.139900 | 11.998000 / 24.103100 / 24.103100 | 1.75x |
| accepted_use_warm_exact_retry | 0.015400 / 0.019700 / 0.019700 | 0.014400 / 0.023400 / 0.023400 | 1.07x |
| accepted_use_receipts_1_memories_workers_1 | 50.482200 / 52.068300 / 52.068300 | 23.141700 / 35.650300 / 35.650300 | 2.18x |
| accepted_use_receipts_1_memories_workers_2 | 50.435500 / 53.104900 / 53.104900 | 23.381100 / 25.575600 / 25.575600 | 2.16x |
| accepted_use_receipts_1_memories_workers_4 | 50.663800 / 53.973800 / 53.973800 | 23.069600 / 25.054800 / 25.054800 | 2.20x |
| accepted_use_receipts_1_memories_workers_8 | 50.831500 / 51.648100 / 51.648100 | 23.347600 / 27.288500 / 27.288500 | 2.18x |
| accepted_use_receipts_4_memories_workers_1 | 83.781100 / 88.742500 / 88.742500 | 23.555100 / 24.695100 / 24.695100 | 3.56x |
| accepted_use_receipts_4_memories_workers_2 | 83.275700 / 86.420500 / 86.420500 | 24.302400 / 25.955700 / 25.955700 | 3.43x |
| accepted_use_receipts_4_memories_workers_4 | 85.935600 / 93.037600 / 93.037600 | 24.385000 / 25.718600 / 25.718600 | 3.52x |
| accepted_use_receipts_4_memories_workers_8 | 85.798700 / 90.761100 / 90.761100 | 24.634500 / 28.445400 / 28.445400 | 3.48x |
| accepted_use_receipts_16_memories_workers_1 | 218.394700 / 259.171700 / 259.171700 | 25.367200 / 29.354900 / 29.354900 | 8.61x |
| accepted_use_receipts_16_memories_workers_2 | 216.371900 / 224.843400 / 224.843400 | 27.194300 / 28.417200 / 28.417200 | 7.96x |
| accepted_use_receipts_16_memories_workers_4 | 278.366300 / 289.125500 / 289.125500 | 86.778600 / 91.357900 / 91.357900 | 3.21x |
| accepted_use_receipts_16_memories_workers_8 | 314.020900 / 334.415600 / 334.415600 | 118.953000 / 123.093200 / 123.093200 | 2.64x |
| accepted_use_receipts_64_memories_workers_1 | 860.660700 / 899.812500 / 899.812500 | 124.915300 / 141.417200 / 141.417200 | 6.89x |
| accepted_use_receipts_64_memories_workers_2 | 937.577100 / 947.717900 / 947.717900 | 192.590800 / 203.680100 / 203.680100 | 4.87x |
| accepted_use_receipts_64_memories_workers_4 | 962.834600 / 978.148800 / 978.148800 | 201.331900 / 228.634900 / 228.634900 | 4.78x |
| accepted_use_receipts_64_memories_workers_8 | 1025.804600 / 1054.485600 / 1054.485600 | 257.798800 / 279.159700 / 279.159700 | 3.98x |
| reopen | 425.429000 / 453.820000 / 453.820000 | 433.345500 / 455.100000 / 455.100000 | 0.98x |
| accepted_use_reopen_exact_retry | 4.050300 / 4.096200 / 4.096200 | 4.052700 / 4.119100 / 4.119100 | 1.00x |
| initial_dream_1_root_reopen_retry | 0.002700 / 0.003300 / 0.003300 | 0.002500 / 0.003400 / 0.003400 | 1.08x |
| initial_dream_2_root_reopen_retry | 0.001300 / 0.001600 / 0.001600 | 0.001300 / 0.009900 / 0.009900 | 1.00x |
| initial_dream_4_root_reopen_retry | 0.001000 / 0.001600 / 0.001600 | 0.001100 / 0.002400 / 0.002400 | 0.91x |
| initial_dream_8_root_reopen_retry | 0.001100 / 0.001800 / 0.001800 | 0.001000 / 0.001300 / 0.001300 | 1.10x |

Stationary history shapes use 64 published Memories, no active Memory graph, same-turn source-only effects, saturation at 100, and seed construction outside timed samples. Every pair matches payload bytes, accepted event count, current/historical records; each executable verifies current records after reopen.
| Depth / batch / stage | P0 p50 / p95 / p99 ms | Final p50 / p95 / p99 ms | Median speedup |
| --- | ---: | ---: | ---: |
| 160 / 1 / history_accepted_use | 13.081200 / 14.298100 / 14.298100 | 0.447600 / 0.540700 / 0.540700 | 29.23x |
| 160 / 1 / history_exact_retry | 0.013900 / 0.015700 / 0.015700 | 0.016200 / 0.017700 / 0.017700 | 0.86x |
| 160 / 64 / history_accepted_use | 240.904800 / 252.837400 / 252.837400 | 1.844800 / 1.900700 / 1.900700 | 130.59x |
| 160 / 64 / history_exact_retry | 0.210600 / 0.215900 / 0.215900 | 0.209900 / 0.227500 / 0.227500 | 1.00x |
| 1024 / 1 / history_accepted_use | 26.884200 / 29.310900 / 29.310900 | 0.486300 / 0.599500 / 0.599500 | 55.28x |
| 1024 / 1 / history_exact_retry | 0.014800 / 0.017700 / 0.017700 | 0.019500 / 0.019700 / 0.019700 | 0.76x |
| 1024 / 64 / history_accepted_use | 572.446300 / 584.585600 / 584.585600 | 1.870700 / 1.877000 / 1.877000 | 306.01x |
| 1024 / 64 / history_exact_retry | 0.208600 / 0.214800 / 0.214800 | 0.215200 / 0.239400 / 0.239400 | 0.97x |
